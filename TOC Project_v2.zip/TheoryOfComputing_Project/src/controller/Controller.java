/**
 * @authors Jordon Calder, Anissia Richards, Rojae Davidson 
 */

package controller;

import java.awt.event.ActionEvent;
import model.VendingModel;

public class Controller {
	private VendingModel model;
	int state;
	
	public Controller(){
		model = new VendingModel();
	}
	public void clean() {
		model.init();
	}
	
	public boolean update(ActionEvent event){
		if(event.getSource().toString().contains("$ 5")){
			return model.updateCoins(5);
		}else if(event.getSource().toString().contains("$ 10")){
			return model.updateCoins(10);
		}else if(event.getSource().toString().contains("$ 20")){
			return model.updateCoins(20);
		}
		return false;
	}
	//number of coins
	public int getnumFive(){
		return model.setnumFive();		
	}
	public int getnumTen(){
		return model.setnumTen();		
	}
	public int getnumTwenty(){
		return model.setnumTwenty();		
	}	
	
	//cost of items
	public int getcostDoritos(){
		return model.setcostDoritos();
	}
	public int getcostBigFoot(){
		return model.setcostBigFoot();
	}
	public int getcostCranWata(){
		return model.setcostCranWata();
	}
	public int getcostPepsi(){
		return model.setcostPepsi();
	}
	public int getcostBagJuic(){
		return model.setcostBagJuic();
	}
	
	public void setState(int num) {
		state = num;
	}
	public int getState() {
		return state;
	}
	public int calcCost() {		
		switch(state) {
		case 1: return getcostDoritos(); 
		case 2: return getcostBigFoot(); 
		case 3: return getcostCranWata(); 
		case 4: return getcostPepsi(); 
		case 5: return getcostBagJuic();
		}
		return 0;
	}
	public int getTotalAmtPaid(){
		return model.calcTotalPaid();		
	}
	public int getcalcTotalChange()  {
		return model.calcTotalChange(calcCost());		
	}		
	public int[] getChange(){		
		return model.calcChange(calcCost());
	}
	public int[] getrefund(){
		return model.refund();
	}
}
