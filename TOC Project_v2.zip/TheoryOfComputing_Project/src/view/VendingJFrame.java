/**
 * @authors Jordon Calder, Anissia Richards, Rojae Davidson 
 */

package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.Controller;

public class VendingJFrame extends JFrame implements ActionListener {

	private static final long serialVersionUID = -4228143491173048986L;

	private JPanel contentPane;
	private JTextField textFieldCost;
	private JTextField textFieldAmnt;
	private JTextField textFieldChange;
	private JTextField textFieldFive;
	private JTextField textFieldTen;
	private JTextField textFieldTwenty;
	private JButton btnDoritos, btnCranWata, btnBigFoot, btnPepsi, btnBagJuice, btnFive, btnTen, btnTwenty, btnCancel,
			btnPurchase;
	private JLabel lblDoritos, lblBigFoot, lblCranWata, lblPepsi, lblBagJuice;
	private Controller controller;
	private JTextField chNumOfTwenty;
	private JLabel lblChangeCoin;
	private JLabel lblX;
	private JLabel lblX_1;
	private JLabel lblX_2;
	private JTextField chNumOfTen;
	private JTextField chNumOfFive;

	/**
	 * Launch the application.
	 */
	public VendingJFrame(Controller controller) {
		this.controller = controller;
		config();
	}

	/**
	 * Create the frame.
	 */
	private void config() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 355, 530);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		//Name of VM
		JLabel lblUtechVendingMachine = new JLabel("UTech Vending Machine");
		lblUtechVendingMachine.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblUtechVendingMachine.setBounds(99, 11, 158, 45);
		contentPane.add(lblUtechVendingMachine);
		
		//Buttons for selecting items on sale
		btnDoritos = new JButton("Doritos");
		btnDoritos.addActionListener(this);
		btnDoritos.setBounds(10, 59, 109, 23);
		contentPane.add(btnDoritos);

		btnBigFoot = new JButton("Big Foot");
		btnBigFoot.addActionListener(this);
		btnBigFoot.setBounds(10, 93, 109, 23);
		contentPane.add(btnBigFoot);

		btnCranWata = new JButton("CranWata");
		btnCranWata.addActionListener(this);
		btnCranWata.setBounds(10, 127, 109, 23);
		contentPane.add(btnCranWata);

		btnPepsi = new JButton("Pepsi");
		btnPepsi.addActionListener(this);
		btnPepsi.setBounds(10, 161, 109, 23);
		contentPane.add(btnPepsi);

		btnBagJuice = new JButton("Bag Juice");
		btnBagJuice.addActionListener(this);
		btnBagJuice.setBounds(10, 198, 109, 23);
		contentPane.add(btnBagJuice);
		
		//Buttons for selecting coins being entered
		btnFive = new JButton("$ 5");
		btnFive.addActionListener(this);
		btnFive.setBounds(10, 247, 89, 23);
		contentPane.add(btnFive);

		btnTen = new JButton("$ 10");
		btnTen.addActionListener(this);
		btnTen.setBounds(122, 247, 89, 23);
		contentPane.add(btnTen);

		btnTwenty = new JButton("$ 20");
		btnTwenty.addActionListener(this);
		btnTwenty.setBounds(238, 247, 89, 23);
		contentPane.add(btnTwenty);
		
		
		JLabel lblCost = new JLabel("Cost $ :");
		lblCost.setFont(new Font("Times New Roman", Font.ITALIC, 13));
		lblCost.setBounds(10, 328, 89, 20);
		contentPane.add(lblCost);
		
		//Displays the cost of the item selected
		textFieldCost = new JTextField();
		textFieldCost.setText("0");
		textFieldCost.setEditable(false);
		textFieldCost.setBounds(122, 328, 86, 20);
		contentPane.add(textFieldCost);
		textFieldCost.setColumns(10);
		
		
		JLabel lblAmount = new JLabel("Amt Entered $ :");
		lblAmount.setFont(new Font("Times New Roman", Font.ITALIC, 13));
		lblAmount.setBounds(13, 359, 86, 20);
		contentPane.add(lblAmount);

		//Displays the amount of money entered
		textFieldAmnt = new JTextField();
		textFieldAmnt.setText("0");
		textFieldAmnt.setEditable(false);
		textFieldAmnt.setBounds(122, 359, 86, 20);
		contentPane.add(textFieldAmnt);
		textFieldAmnt.setColumns(10);

		JLabel lblChange = new JLabel("Change $ : ");
		lblChange.setFont(new Font("Times New Roman", Font.ITALIC, 13));
		lblChange.setBounds(10, 390, 89, 16);
		contentPane.add(lblChange);
		
		//Displays the amount of change to be returned
		textFieldChange = new JTextField();
		textFieldChange.setEditable(false);
		textFieldChange.setBounds(122, 390, 86, 20);
		contentPane.add(textFieldChange);
		textFieldChange.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel("# of coin:");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.ITALIC, 11));
		lblNewLabel_3.setBounds(10, 281, 54, 14);
		contentPane.add(lblNewLabel_3);

		textFieldFive = new JTextField();
		textFieldFive.setText("0");
		textFieldFive.setEditable(false);
		textFieldFive.setBounds(61, 278, 38, 20);
		contentPane.add(textFieldFive);
		textFieldFive.setColumns(10);

		JLabel lblNewLabel_4 = new JLabel("# of coin:");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.ITALIC, 11));
		lblNewLabel_4.setBounds(122, 281, 54, 14);
		contentPane.add(lblNewLabel_4);

		textFieldTen = new JTextField();
		textFieldTen.setText("0");
		textFieldTen.setEditable(false);
		textFieldTen.setBounds(171, 281, 40, 20);
		contentPane.add(textFieldTen);
		textFieldTen.setColumns(10);

		JLabel lblNewLabel_5 = new JLabel("# of coin:");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.ITALIC, 11));
		lblNewLabel_5.setBounds(248, 281, 54, 14);
		contentPane.add(lblNewLabel_5);

		textFieldTwenty = new JTextField();
		textFieldTwenty.setText("0");
		textFieldTwenty.setEditable(false);
		textFieldTwenty.setBounds(298, 281, 29, 20);
		contentPane.add(textFieldTwenty);
		textFieldTwenty.setColumns(10);

		lblDoritos = new JLabel("$ 50");
		lblDoritos.setBounds(229, 59, 46, 14);
		contentPane.add(lblDoritos);

		lblBigFoot = new JLabel("$ 30");
		lblBigFoot.setBounds(229, 93, 46, 14);
		contentPane.add(lblBigFoot);

		lblCranWata = new JLabel("$ 40");
		lblCranWata.setBounds(229, 127, 46, 14);
		contentPane.add(lblCranWata);

		lblPepsi = new JLabel("$ 35");
		lblPepsi.setBounds(229, 161, 46, 14);
		contentPane.add(lblPepsi);

		lblBagJuice = new JLabel("$ 15");
		lblBagJuice.setBounds(229, 198, 46, 14);
		contentPane.add(lblBagJuice);

		btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(this);
		btnCancel.setBounds(171, 456, 89, 23);
		contentPane.add(btnCancel);

		chNumOfTwenty = new JTextField();
		chNumOfTwenty.setEditable(false);
		chNumOfTwenty.setColumns(10);
		chNumOfTwenty.setBounds(147, 418, 29, 20);
		contentPane.add(chNumOfTwenty);

		lblChangeCoin = new JLabel("Change in coins : ");
		lblChangeCoin.setFont(new Font("Times New Roman", Font.ITALIC, 13));
		lblChangeCoin.setBounds(10, 418, 99, 20);
		contentPane.add(lblChangeCoin);

		lblX = new JLabel("20 x");
		lblX.setFont(new Font("Times New Roman", Font.ITALIC, 11));
		lblX.setBounds(122, 418, 29, 20);
		contentPane.add(lblX);

		lblX_1 = new JLabel("10 x");
		lblX_1.setFont(new Font("Times New Roman", Font.ITALIC, 11));
		lblX_1.setBounds(178, 418, 29, 20);
		contentPane.add(lblX_1);

		lblX_2 = new JLabel(" 5 x");
		lblX_2.setFont(new Font("Times New Roman", Font.ITALIC, 11));
		lblX_2.setBounds(233, 419, 29, 20);
		contentPane.add(lblX_2);

		chNumOfTen = new JTextField();
		chNumOfTen.setEditable(false);
		chNumOfTen.setColumns(10);
		chNumOfTen.setBounds(204, 418, 29, 20);
		contentPane.add(chNumOfTen);

		chNumOfFive = new JTextField();
		chNumOfFive.setEditable(false);
		chNumOfFive.setColumns(10);
		chNumOfFive.setBounds(257, 418, 29, 20);
		contentPane.add(chNumOfFive);

		btnPurchase = new JButton("Purchase");
		btnPurchase.addActionListener(this);
		btnPurchase.setBounds(62, 456, 89, 23);
		contentPane.add(btnPurchase);
		this.setLocationRelativeTo(null);
		setVisible(true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent event) {
		boolean updated = false;
				
		if (event.getSource().equals(btnFive) || event.getSource().equals(btnTen)|| event.getSource().equals(btnTwenty)) {
			updated = controller.update(event); //counts number of coins
			if (!updated)
				JOptionPane.showMessageDialog(null, "Coin Update error. Select Cancel");
			else {
				if (event.getSource().equals(btnFive))
					textFieldFive.setText("" + controller.getnumFive());
				else if (event.getSource().equals(btnTwenty))
					textFieldTwenty.setText("" + controller.getnumTwenty());
				else if (event.getSource().equals(btnTen))
					textFieldTen.setText("" +  controller.getnumTen());
				updateAmnt();//update the amount paid
			}			
		}else if (event.getSource().equals(btnCancel)) {					
			updateRefund(controller.getrefund());			
			JOptionPane.showMessageDialog(null, "Sorry to see you go");	
			clearScreen();
			EnableButtons();
			//this.dispose();
		}else if (event.getSource().equals(btnPurchase)) {
							if (isPurchaseValid()) { // check if an item was selected
								if(Integer.parseInt(textFieldAmnt.getText())!=0){ //check if any money was entered
									if(Integer.parseInt(textFieldAmnt.getText())>=Integer.parseInt(textFieldCost.getText())){//check if amount entered	is greater than or equal to the cost	
										if (Integer.parseInt(textFieldAmnt.getText()) > 50) {
											//System.out.println(Integer.parseInt(textFieldAmnt.getText()) + " " + 50);
											updateRefund(controller.getrefund());
											JOptionPane.showMessageDialog(null, "Too much funds!");
											clearScreen();
											controller.clean();	
											EnableButtons();
										}else {
										updateChange(controller.getChange());
										JOptionPane.showMessageDialog(null, "Thank you for supporting Us!");
										clearScreen();
										controller.clean();	
										EnableButtons();
										}
									}else
										JOptionPane.showMessageDialog(null, "Insufficient funds to make purchase!");
								}else
									JOptionPane.showMessageDialog(null, "No coins Entered!");
							}
							else
								JOptionPane.showMessageDialog(null, "No item selected!");							
		}else 
			updateCost(event);		
	}
	private boolean isPurchaseValid() {	
		if(controller.getState()!=0) //if an item was selected
			return true;
		else 
			return false;
	}	
	private void updateChange(int[] change) {				
		chNumOfTwenty.setText("" + change[0]);
		chNumOfTen.setText("" + change[1]);
		chNumOfFive.setText("" + change[2]);
		textFieldChange.setText(""+ controller.getcalcTotalChange());		
	}
	private void updateRefund(int[] change) {
		
		int sum = ((change[0]*20)+ (change[1]*10)+ (change[2]*5));
		chNumOfTwenty.setText("" + change[0]);
		chNumOfTen.setText("" + change[1]);
		chNumOfFive.setText("" + change[2]);
		textFieldChange.setText(""+ sum);		
	}
	private void clearScreen() {				
		chNumOfTwenty.setText("");
		chNumOfTen.setText("" );
		chNumOfFive.setText("");
		textFieldAmnt.setText("0");
		textFieldFive.setText("0");
		textFieldTen.setText("0");
		textFieldTwenty.setText("0");		
		textFieldChange.setText("0");
		textFieldCost.setText("0");
	}
	private void updateAmnt() {
		textFieldAmnt.setText("" + controller.getTotalAmtPaid());
	}
	private void DisableButtons() {
		btnDoritos.setEnabled(false);btnBigFoot.setEnabled(false); btnCranWata.setEnabled(false); btnPepsi.setEnabled(false); btnBagJuice.setEnabled(false);
	}
	private void EnableButtons() {
		btnDoritos.setEnabled(true);btnBigFoot.setEnabled(true); btnCranWata.setEnabled(true); btnPepsi.setEnabled(true); btnBagJuice.setEnabled(true);
		
		btnDoritos.setBackground(null);btnBigFoot.setBackground(null); btnCranWata.setBackground(null); btnPepsi.setBackground(null); btnBagJuice.setBackground(null);
	}
	private void updateCost(ActionEvent event){		
		if (event.getSource().equals(btnDoritos)) {
			textFieldCost.setText(""+(Integer.parseInt(textFieldCost.getText())+controller.getcostDoritos()));//0 from string to integer then add 50
			controller.setState(1);
			btnDoritos.setBackground(new Color(153,255,255));
			DisableButtons();
		}else if (event.getSource().equals(btnBigFoot)) {
				textFieldCost.setText(""+(Integer.parseInt(textFieldCost.getText())+controller.getcostBigFoot()));
				controller.setState(2);
				btnBigFoot.setBackground(new Color(153,255,255));
				DisableButtons();
		}else if (event.getSource().equals(btnCranWata)) {
					textFieldCost.setText(""+(Integer.parseInt(textFieldCost.getText())+controller.getcostCranWata()));
					controller.setState(3);
					btnCranWata.setBackground(new Color(153,255,255));
					DisableButtons();
		}else if (event.getSource().equals(btnPepsi)) {
						textFieldCost.setText(""+(Integer.parseInt(textFieldCost.getText())+controller.getcostPepsi()));
						controller.setState(4);
						btnPepsi.setBackground(new Color(153,255,255));
						DisableButtons();
		}else if (event.getSource().equals(btnBagJuice)) {
							textFieldCost.setText(""+(Integer.parseInt(textFieldCost.getText())+controller.getcostBagJuic()));
							controller.setState(5);
							btnBagJuice.setBackground(new Color(153,255,255));
							DisableButtons();
		}
	}	
}
