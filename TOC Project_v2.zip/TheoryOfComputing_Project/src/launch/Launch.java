/**
 * 
 */
package launch;

import java.awt.EventQueue;

import controller.Controller;
import view.VendingJFrame;

/**
 * @author Jordon Calder
 *
 * @email jordon_calder@outlook.com
 *
 * @tele: 18768532705
 */
public class Launch {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// create new Marker Inventory View and run
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				new VendingJFrame(new Controller() // initialize new controller
				);

			}
		});

	}

}
