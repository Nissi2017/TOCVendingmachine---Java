
/**
 * @authors Jordon Calder, Anissia Richards, Rojae Davidson 
 */
package model;

public class VendingModel {
	private int five, ten, twenty;	
	private int numten, numtwenty, numfive, totalpaid ,chdivten, chdivfive, chdivtwenty, temppaid;

	public VendingModel(){
		init();
	}
	public void init(){
		five = 5;
		ten = 10;
		twenty = 20;

		numten = 0;
		numtwenty = 0;
		numfive = 0;
		totalpaid = 0;
		chdivten =0;
		chdivfive = 0;
		chdivtwenty = 0;
	}
	public int setcostDoritos(){
		return 50;
	}
	public int setcostBigFoot(){
		return 30;
	}
	public int setcostCranWata(){
		return 40;
	}
	public int setcostPepsi(){
		return 35;
	}
	public int setcostBagJuic(){
		return 15;
	}
		
	public int calcTotalPaid() {
		totalpaid =  (numfive * five) + (numten * ten) + (numtwenty * twenty);		
		temppaid = totalpaid;
		return totalpaid;
	}
		
	public boolean updateCoins(int coins){//counts the number of coins entered based on the coin type
		if(coins == five){
			numfive++;
			return true;
		}else if(coins == twenty){
			numtwenty++;
			return true;
		}else if(coins == ten){
			numten++;
			return true;
		}
		return false;
	}
	//returns the number of the coins entered
	public int setnumFive(){
		return numfive;		
	}
	public int setnumTen(){
		return numten;		
	}
	public int setnumTwenty(){
		return numtwenty;		
	}
	public int twenty(int change) {
		chdivtwenty = change / twenty; // number of times 20 can go into change
		return change-(chdivtwenty * twenty); // returns the remainder after divided by 20
	}
	public int ten(int change) {
		chdivten = change / ten; // number of times 10 can go into change
		return change-(chdivten * ten); //return the remainder after divided by 20
	}
	public int five(int change) {
		chdivfive = change / five; // number of times 10 can go into change
		return change-(chdivfive * five);
	}
	public int[] calcChange(int costofitem) { 

		int[] change = null;
		
		int tempchange = totalpaid - costofitem; // calculate change
		if ((tempchange %twenty) >= 0) {
				tempchange = twenty(tempchange);
				if((tempchange% ten) >= 0){
					tempchange = ten(tempchange);
					if((tempchange %five) >= 0)
						tempchange = five(tempchange);
				}
			} else if ((tempchange% ten) >= 0) {
				tempchange = ten(tempchange);
				if((tempchange %five) >= 0)
					tempchange = five(tempchange);
			} else if ((tempchange% five) >= 0) {
				tempchange = five(tempchange);
			}
		change = new int[]{chdivtwenty,chdivten,chdivfive};
		init(); //reinistialize all variable data
		return change;		
		
	}
	public int[] refund(){ //if purchase is cancelled
		int[] change = new int[]{numtwenty,numten,numfive};
		return change;
	}
	public int calcTotalChange(int costofitem) {		
		return temppaid - costofitem;
	}


}
